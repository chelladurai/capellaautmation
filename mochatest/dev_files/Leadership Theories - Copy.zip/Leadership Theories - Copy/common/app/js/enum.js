//QUESTION TYPES
var QUESTION_TYPE_MULTIPLE_CHOICE = "multiple_choice";
var QUESTION_TYPE_MULTIPLE_SELECT = "multiple_select";
var QUESTION_TYPE_FILL_IN_THE_BLANK = "fill_in_the_blank";
var QUESTION_TYPE_EXPERT_RESPONSE = "expert_response";


//COMPETENCIES
var COMPETENCY_1 = "competency_1";
var COMPETENCY_2 = "competency_2";
var COMPETENCY_3 = "competency_3";

var QUESTION_FEEDBACK_CORRECT_ANSWER_TEXT = "Feedback";
var QUESTION_FEEDBACK_INCORRECT_ANSWER_TEXT = "Feedback";
var QUESTION_FEEDBACK_CORRECT_ANSWERS_TEXT = "Correct Answers";

var FEEDBACK_TYPE_QUESTION = "Question";
var FEEDBACK_TYPE_ANSWER = "Answer";

var STATUS_CORRECT = "Correct";
var STATUS_INCORRECT = "Incorrect";
var STATUS_INCOMPLETE = "Incomplete";