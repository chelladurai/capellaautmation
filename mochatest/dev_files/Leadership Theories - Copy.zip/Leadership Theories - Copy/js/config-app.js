var IME_MEDIA_ID = "HIM4670_LeadershipTheories";

//var DATA_PATH = "/CourseMedia/QuizEngine/data/Leadership Theories.json";
var DATA_PATH = "data/Leadership Theories.json"
//IME_OVERRIDE_USER_ID = "MTAYLOR87";