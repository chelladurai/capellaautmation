(function( quizApp, $, undefined ) {
	//PRIVATE VARS
	
	//PUBLIC VARS
	
	//PRIVATE METHODS

	
	//PUBLIC METHODS

	$(document).ready(function(){
		quizAppCommon.init();
		//quizApp.init();
	});

	quizApp.serialize = function() {
	
	}
	
	quizApp.init = function() {
	
	}
	
	quizApp.deserialize = function() {
		
	
	}
	
	quizApp.initVars = function() {

	}
	
	quizApp.initPlugins = function() {
		
	}
	
	quizApp.setBindings = function() {		
		
		
	}
	
	quizApp.render = function() {

	}
	
	quizApp.checkForQuizAllAnswered = function() {
		
	}


}( window.quizApp = window.quizApp || {}, jQuery ));

